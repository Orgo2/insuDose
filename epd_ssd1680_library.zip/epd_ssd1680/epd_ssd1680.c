#include "epd_ssd1680.h"
#include "ascii_8x12.h"

// Dummy implementation
void epd_init(void) {}
void epd_clear(uint8_t color) {}
void epd_draw_char(uint8_t x, uint8_t y, char c) {}
void epd_draw_string(uint8_t x, uint8_t y, const char *str) {}
void epd_update(void) {}
