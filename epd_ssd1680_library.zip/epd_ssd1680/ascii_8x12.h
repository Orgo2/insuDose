#ifndef ASCII_8X12_H
#define ASCII_8X12_H

#include <stdint.h>

extern const uint8_t font8x12[96][12];

#endif
