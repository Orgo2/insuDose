#include "ascii_8x12.h"

const uint8_t font8x12[96][12] = {
    {0} // Fill in actual font data here
};
